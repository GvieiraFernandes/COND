<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $email = $_POST["email"];
  $sobrenome = $_POST["sobrenome"];
  $assunto = $_POST["assunto"];
  $mensagem = $_POST["mensagem"];

  $to = "annajulyatrabalho@gmail.com";
  $headers = "From: $name <$email>";
  $body = "Assunto: $assunto\n\nMensagem: $mensagem";

  if (mail($to, $assunto, $body, $headers)) {
    echo "E-mail enviado com sucesso!";
  } else {
    echo "Erro ao enviar o e-mail.";
  }
}
?>